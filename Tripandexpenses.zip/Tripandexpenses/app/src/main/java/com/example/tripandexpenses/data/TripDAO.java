package com.example.tripandexpenses.data;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.tripandexpenses.Constants;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class TripDAO {
    private SQLiteDatabase db;
    public MutableLiveData<tripEnity> Trip;
    public  MutableLiveData<List<tripEnity>> triplist;

    public TripDAO(Context context) throws ParseException {
        DBhender data = new DBhender(context);
        db = data.getWritableDatabase();
        System.out.println(db);
        Trip = new MutableLiveData<tripEnity>();
        triplist = new MutableLiveData<List<tripEnity>>();
        {
            triplist.setValue(getAll());
        }
    }
    @SuppressLint("Range")
    public List<tripEnity> get(String sql, String ...selectArgs) {
        List<tripEnity> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, selectArgs );

        while (cursor.moveToNext()){
            tripEnity trip = new tripEnity();
            trip.setId(cursor.getString(cursor.getColumnIndex("id")));
            trip.setName(cursor.getString(cursor.getColumnIndex("name")));
            trip.setDestination(cursor.getString(cursor.getColumnIndex("destination")));
            trip.setDate(cursor.getString(cursor.getColumnIndex("date")));
            trip.setRisk(cursor.getString(cursor.getColumnIndex("risk")));
            trip.setDescription(cursor.getString(cursor.getColumnIndex("description")));
            list.add(trip);
        }
        return list;
    }
    public List<tripEnity> getAll(){
        String sql = "SELECT * FROM trip";
        return get(sql);
    }
    public tripEnity getById(String id){
        String sql = "SELECT*FROM trip WHERE id = ?";
        List<tripEnity> list = get(sql, id);
        Trip.setValue(list.get(0));
        return list.get(0);
    }
    public void getTripById(String id){
        if (id == null || id.equals(Constants.NEW_TRIP_ID)) {
            Trip.setValue(new tripEnity());
            return;
        }
        getById(id);
    }
    public long insert(tripEnity trip){
        ContentValues values = new ContentValues();
        values.put("name", trip.getName());
        values.put("destination", trip.getDestination());
        values.put("date", trip.getDate());
        values.put("risk", trip.getRisk());
        values.put("description", trip.getDescription());
        System.out.println(values);

        return  db.insert("TRIP", null, values);

    }
    public long update(tripEnity trip){
        ContentValues values = new ContentValues();
        values.put("name", trip.getName());
        values.put("destination", trip.getDestination());
        values.put("date", trip.getDate());
        values.put("risk", trip.getRisk());
        values.put("description", trip.getDescription());

        return  db.update("trip", values, "id=?", new String[]{trip.getId()});
    }
    public int delete(String id){
        return db.delete("trip", "id=?", new String[]{id});
    }
    public void search(String text) {
        String query = "Select * from trip WHERE name LIKE '%"+text+"%' OR destination LIKE '%"+text+"%' OR date LIKE '%"+text+"%'";
        triplist.setValue(get(query));
    }
}
