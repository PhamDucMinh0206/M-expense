package com.example.tripandexpenses;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tripandexpenses.data.expenseTrip;
import com.example.tripandexpenses.databinding.ListItemBinding;

import java.util.List;

public class expenseListApdapter extends RecyclerView.Adapter<expenseListApdapter.ExpenseViewHolper> {
    private List<expenseTrip> expenseList;
    private expenseListApdapter.ListItemListener listener;

    public interface ListItemListener{
        void onItemClick(String hotelID);
    }

    public expenseListApdapter(List<expenseTrip> expenseList, expenseListApdapter.ListItemListener listener) {
        this.expenseList = expenseList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ExpenseViewHolper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new expenseListApdapter.ExpenseViewHolper(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolper holder, int position) {
        expenseTrip eData = expenseList.get(position);
        holder.bindData(eData);
    }

    @Override
    public int getItemCount() {
        return expenseList.size();
    }

    public class ExpenseViewHolper extends RecyclerView.ViewHolder {

        private final ListItemBinding itemViewBinding;



        public ExpenseViewHolper(View itemView) {
            super(itemView);
            itemViewBinding = ListItemBinding.bind(itemView);
        }

        public void bindData(expenseTrip eData) {
            itemViewBinding.tripName.setText(eData.getTypeOfExpense());
            itemViewBinding.getRoot().setOnClickListener(v -> listener.onItemClick(eData.getId()));
        }
    }


}
