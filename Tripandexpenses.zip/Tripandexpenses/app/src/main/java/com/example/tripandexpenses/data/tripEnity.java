package com.example.tripandexpenses.data;

import com.example.tripandexpenses.Constants;

import java.util.HashMap;
import java.util.Map;

public class tripEnity {
    private String id;
    private String name;
    private String destination;
    private String date;
    private String risk;
    private String description;


    @Override
    public String toString() {
        return "TripEnity{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", destination='" + destination + '\'' +
                ", date='" + date + '\'' +
                ", risk='" + risk + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    public tripEnity() {
        this(
                Constants.NEW_TRIP_ID,
                Constants.EMPTY_STRING,
                Constants.EMPTY_STRING,
                Constants.EMPTY_STRING,
                Constants.EMPTY_STRING,
                Constants.EMPTY_STRING
        );
    }

    public tripEnity(String name, String destination, String date, String risk, String description) {
        this(Constants.NEW_TRIP_ID, name, destination, date, risk, description);
    }

    public tripEnity(String id, String name, String destination, String date, String risk, String description) {
        setId(id);
        setName(name);
        setDestination(destination);
        setDate(date);
        setRisk(risk);
        setDescription(description);
    }

    public Map<String, Object> getMapWithoutId() {
        Map<String, Object> bMap = new HashMap<>();
        bMap.put("name", this.name);
        bMap.put("description", this.description);
        bMap.put("destination", this.destination);
        bMap.put("risk", this.risk);
        bMap.put("date", this.date);
        return bMap;


    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRisk() {
        return risk;
    }

    public void setRisk(String risk) {
        this.risk = risk;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
