package com.example.tripandexpenses;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.example.tripandexpenses.data.DBhender;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBhender dbHelper = new DBhender(this);
        SQLiteDatabase database = dbHelper.getReadableDatabase();
    }
}