package com.example.tripandexpenses.data;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.lifecycle.MutableLiveData;

import com.example.tripandexpenses.Constants;

import java.util.ArrayList;
import java.util.List;

public class ExpenseDAO {
    private SQLiteDatabase db;
    public MutableLiveData<List<expenseTrip>> expenseList;
    public MutableLiveData<expenseTrip> expense;
    String tripId;

    public ExpenseDAO(Context context, String tripId) {
        DBhender helper = new DBhender(context);

        db = helper.getWritableDatabase();

        this.tripId = tripId;

        expenseList = new MutableLiveData<List<expenseTrip>>();
        {
            expenseList.setValue(getAll());
        }
        expense = new MutableLiveData<expenseTrip>();
    }

    @SuppressLint("Range")
    public List<expenseTrip> get(String sql, String ...selectArgs) {
        List<expenseTrip> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, selectArgs);

        while(cursor.moveToNext()) {
            expenseTrip e = new expenseTrip();
            e.setId(cursor.getString(cursor.getColumnIndex("id")));
            e.setIdTrip(cursor.getString(cursor.getColumnIndex("idTrip")));
            e.setTypeOfExpense(cursor.getString(cursor.getColumnIndex("typeOfExpense")));
            e.setAmountOfTheExpense(cursor.getDouble(cursor.getColumnIndex("amount")));
            e.setTimeOfTheExpense(cursor.getString(cursor.getColumnIndex("time")));
            e.setAdditionalComments(cursor.getString(cursor.getColumnIndex("additionalComments")));

            list.add(e);
        }
        return list;
    }
    public List<expenseTrip> getAll() {
        String sql = "SELECT * FROM EXPENSE WHERE idTrip = ?";

        return get(sql, tripId);
    }

    public expenseTrip getById(String id) {
        String sql = "SELECT * FROM EXPENSE WHERE id = ? and idTrip = ?";

        List<expenseTrip> list = get(sql, id, tripId);
        expense.setValue(list.get(0));
        return list.get(0);
    }

    public void getExpenseById(String id){
        if (id == null || id.equals(Constants.NEW_EXPENSE_ID)) {
            expense.setValue(new expenseTrip());
            return;
        }
        getById(id);
    }


    public long insert(expenseTrip e) {
        ContentValues values = new ContentValues();
        values.put("idTrip", e.getIdTrip());
        values.put("typeOfExpense", e.getTypeOfExpense());
        values.put("amount", e.getAmountOfTheExpense());
        values.put("time", e.getTimeOfTheExpense());
        values.put("additionalComments", e.getAdditionalComments());

        return db.insert("EXPENSE", null, values);
    }

    public long update(expenseTrip e) {
        ContentValues values = new ContentValues();
        values.put("typeOfExpense", e.getTypeOfExpense());
        values.put("amount", e.getAmountOfTheExpense());
        values.put("time", e.getTimeOfTheExpense());
        values.put("additionalComments", e.getAdditionalComments());

        return db.update("EXPENSE", values, "id=?", new String[]{e.getId()});
    }

    public int delete(String id) {
        return db.delete("EXPENSE", "id=?", new String[]{id});
    }
}
