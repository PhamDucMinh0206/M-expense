package com.example.tripandexpenses;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TimePicker;

import com.example.tripandexpenses.data.ExpenseDAO;
import com.example.tripandexpenses.data.TripDAO;
import com.example.tripandexpenses.data.expenseTrip;
import com.example.tripandexpenses.data.tripEnity;
import com.example.tripandexpenses.databinding.FragmentEditorBinding;
import com.example.tripandexpenses.databinding.FragmentEditorExpenseBinding;
import com.google.android.material.textfield.TextInputLayout;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class EditorExpenseFragment extends Fragment {

    private EditorExpenseViewModel mViewModel;
    private FragmentEditorExpenseBinding binding;
    private ExpenseDAO expenseDAO;

    String expenseId;
    String tripId;
    String typeExpense;

    String[] listTypeOfExpense = {"Travel", "Food", "Lodging", "Internet Access", "Ground Transportation"};
    AutoCompleteTextView autoCompleteTypeExpenses;
    ArrayAdapter<String> adapterTypeExpenses;

    EditText date_time_in;
    SimpleDateFormat sdf = new SimpleDateFormat("MMM dd YYY HH:mm:ss");

    public static EditorExpenseFragment newInstance() {
        return new EditorExpenseFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        AppCompatActivity app = (AppCompatActivity)getActivity();
        ActionBar ab = app.getSupportActionBar();

        ab.setHomeButtonEnabled(true);

        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        ab.setHomeAsUpIndicator(R.drawable.ic_24);
        setHasOptionsMenu(true);
        binding= FragmentEditorExpenseBinding.inflate(inflater,container,false);
        expenseId = getArguments().getString("id");
        tripId = getArguments().getString("tripId");
        typeExpense = getArguments().getString("typeOfExpense");
        expenseDAO = new ExpenseDAO(getContext(), tripId);

        autoCompleteTypeExpenses = binding.autoCompleteTypeExpenses;
        adapterTypeExpenses = new ArrayAdapter<String>(requireContext(), R.layout.drop_item, listTypeOfExpense);


        expenseDAO.expense.observe(
                getViewLifecycleOwner(),
                t -> {
                    binding.autoCompleteTypeExpenses.setText(getArguments().getString("type"));
                    binding.additionalComments.setText(getArguments().getString("additional"));
                    binding.amount.setText(getArguments().getString("amout"));
                    binding.editDateTime.setText(getArguments().getString("date"));
                    autoCompleteTypeExpenses.setAdapter(adapterTypeExpenses);

                    requireActivity().invalidateOptionsMenu();
                }
        );

        expenseDAO.getExpenseById(expenseId);



        date_time_in = binding.editDateTime;
        date_time_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimeDialog(date_time_in);
            }
        });

        return binding.getRoot();

    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        super.onPrepareOptionsMenu(menu);
        expenseTrip t = expenseDAO.expense.getValue();
        if(t != null && t.getId() == Constants.NEW_TRIP_ID) {
            menu.findItem(R.id.action_delete).setVisible(false);
        }
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.menu_delete, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (this.validate()) {
                    return saveAndReturn() ;
                }
                else return false;
            case R.id.action_delete:
                return deleteAndReturn(expenseId);
            default: return super.onOptionsItemSelected(item);
        }
    }

    private boolean saveAndReturn() {
        String typeExpense = binding.autoCompleteTypeExpenses.getText().toString();
        double amountExpense = Double.parseDouble(binding.amount.getText().toString());
        String dateOfTheExpense = binding.editDateTime.getText().toString();
        String commentsExpense = binding.additionalComments.getText().toString();

        expenseTrip updateExpense = new expenseTrip(expenseId != null ? expenseId: Constants.NEW_EXPENSE_ID, tripId ,typeExpense, amountExpense, dateOfTheExpense, commentsExpense);

        if(expenseId == null) {
            expenseDAO.insert(updateExpense);
        } else {
            expenseDAO.update(updateExpense);
        }

        Navigation.findNavController(getView()).navigateUp();
        return true;
    }

    private boolean validate() {
        TextInputLayout inputLayoutTypeOfExpense = binding.typeOf;
        AutoCompleteTextView textViewTypeOfExpense = binding.autoCompleteTypeExpenses;
        EditText amount = binding.amount;


        boolean isValidated = true;

//        if (textViewTypeOfExpense.getText().toString().equals(Constants.EMPTY_STRING)){
//            inputLayoutTypeOfExpense.setError("Type is require");
//            isValidated = false;
//        }
        if (amount.getText().toString().equals(Constants.EMPTY_STRING)){
            amount.setError("Destination is require");
            isValidated = false;
        }

        return isValidated;
    }

    private boolean deleteAndReturn(String id) {
        Log.i(this.getClass().getName(), "delete and return");
        expenseDAO.delete(id);
        Navigation.findNavController(getView()).navigateUp();
        return true;
    }

    private void showDateTimeDialog(EditText date) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);

                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");

                        date.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(requireContext(), timeSetListener,
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(requireContext(), dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }
    private int checkRadioId(String rId) {
        if(rId == null || rId.equals("true")) {
            rId = "-1";
        }
        return Integer.parseInt(rId);
    }
    }



