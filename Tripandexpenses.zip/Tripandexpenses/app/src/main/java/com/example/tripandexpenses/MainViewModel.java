package com.example.tripandexpenses;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.tripandexpenses.data.SampleDataProvider;
import com.example.tripandexpenses.data.tripEnity;

import java.util.List;

public class MainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
    MutableLiveData<List<tripEnity>> tripList = new MutableLiveData<List<tripEnity>>();
    {
        tripList.setValue(SampleDataProvider.getTrips());
    }
}