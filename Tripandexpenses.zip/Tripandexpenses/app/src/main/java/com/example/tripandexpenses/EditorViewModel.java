package com.example.tripandexpenses;

import androidx.lifecycle.ViewModel;

public class EditorViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}