package com.example.tripandexpenses;

public class Constants {
    public static final String EMPTY_STRING = "";
    public static final String NEW_TRIP_ID = "0";
    public static final String NEW_EXPENSE_ID = null;
    public static final double PRICE_DEFAULT = 1.0;

}
