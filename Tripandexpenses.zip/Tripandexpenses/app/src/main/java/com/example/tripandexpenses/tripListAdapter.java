package com.example.tripandexpenses;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tripandexpenses.data.tripEnity;
import com.example.tripandexpenses.databinding.ListItemBinding;

import java.util.List;

public class tripListAdapter extends RecyclerView.Adapter<tripListAdapter.TripviewHolper> {
    private List<tripEnity> tripList;
    private ListItemListener listener;

    public interface ListItemListener{
        void onItemClick(String hotelID);
    }

    public tripListAdapter(List<tripEnity> tripList, ListItemListener listener) {
        this.tripList = tripList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TripviewHolper onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new TripviewHolper(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TripviewHolper holder, int position) {
        tripEnity bData = tripList.get(position);
        holder.bindData(bData);
    }

    @Override
    public int getItemCount() {
        return tripList.size();
    }

    public class TripviewHolper extends RecyclerView.ViewHolder {

        private final ListItemBinding itemViewBinding;



        public TripviewHolper(View itemView) {
            super(itemView);
            itemViewBinding = ListItemBinding.bind(itemView);
        }

        public void bindData(tripEnity bData) {
            itemViewBinding.tripName.setText(bData.getName());
            itemViewBinding.getRoot().setOnClickListener(v -> listener.onItemClick(bData.getId()));
        }
    }
}
