package com.example.tripandexpenses.data;

import java.util.ArrayList;
import java.util.List;

public class SampleDataProvider {
    public static List<tripEnity> getTrips() {
        List<tripEnity> trips = new ArrayList<>();
        trips.add(new tripEnity("1", "hotel", "one", "hello",
                "Yes", "Free"));

        return trips;
    }
}