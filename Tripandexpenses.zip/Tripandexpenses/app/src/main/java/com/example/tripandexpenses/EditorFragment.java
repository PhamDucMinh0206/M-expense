package com.example.tripandexpenses;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TimePicker;

import com.example.tripandexpenses.data.TripDAO;
import com.example.tripandexpenses.data.tripEnity;
import com.example.tripandexpenses.databinding.FragmentEditorBinding;
import com.google.android.material.textfield.TextInputLayout;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class EditorFragment extends Fragment {

    private EditorViewModel mViewModel;
    private FragmentEditorBinding binding;
    EditText date;
    SimpleDateFormat Date = new SimpleDateFormat("MMM dd YYY HH:mm:ss");
    private TripDAO tripDao;
    String id;
    RadioGroup radioGroup;
    int rId;
    String[] listTripName = {"Conference","Client meeting", "Holiday", "Visiting", "Discovery", "Interview"};
    String[] listTripDestination = {"Manchester United", "Arsenal", "Tottenham Hotspur", "Liverpool", "Chelsea", "Manchester City"};

    AutoCompleteTextView autoCompleteTripName;
    AutoCompleteTextView autoCompleteDestination;

    ArrayAdapter<String> adapterTripName;
    ArrayAdapter<String> adapterDestination;
    public static EditorFragment newInstance() {
        return new EditorFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        AppCompatActivity app = (AppCompatActivity)getActivity();
        ActionBar ab = app.getSupportActionBar();

        ab.setHomeButtonEnabled(true);

        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        ab.setHomeAsUpIndicator(R.drawable.ic_24);
        setHasOptionsMenu(true);
        binding= FragmentEditorBinding.inflate(inflater,container,false);
        id = getArguments().getString("id");
        System.out.println(id);
        try {
            tripDao = new TripDAO(getContext());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        autoCompleteTripName = binding.autoCompleteTripName;
        autoCompleteDestination = binding.autoCompleteDestination;

        //create array adapter
        adapterTripName = new ArrayAdapter<String>(requireContext(), R.layout.drop_item, listTripName);
        adapterDestination = new ArrayAdapter<String>(requireContext(), R.layout.drop_item, listTripDestination);
        tripDao.Trip.observe(
                getViewLifecycleOwner(),
                t -> {
                    binding.autoCompleteTripName.setText(getArguments().getString("name"));
                    binding.autoCompleteDestination.setText(getArguments().getString("destination"));
                    binding.riskSelected.setText(getArguments().getString("risk"));
                    binding.date.setText(getArguments().getString("date"));
                    binding.description.setText(getArguments().getString("description"));

                    autoCompleteTripName.setAdapter(adapterTripName);
                    autoCompleteDestination.setAdapter(adapterDestination);

                    requireActivity().invalidateOptionsMenu();
                }
        );

        tripDao.getTripById(id);

        Button buttonExpenseList = binding.navigateToExpense;
        buttonExpenseList.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToExpenseList();
            }
        }));

        radioGroup = binding.radioGroup;
        date = binding.date;
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimeDialog(date);
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radio1:
                    case R.id.radio2:
                        rId = checkedId;
                        break;
                }
            }
        });
        return binding.getRoot();

    }

    private void navigateToExpenseList() {
        Bundle bundle = new Bundle();

        if (id != null) {
            bundle.putString("tripId", id);
            System.out.println(bundle);
            Navigation.findNavController(getView()).navigate(R.id.eOfTFragment, bundle);
        };
        return;
    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        super.onPrepareOptionsMenu(menu);
        tripEnity t = tripDao.Trip.getValue();
        if(t != null && t.getId() == Constants.NEW_TRIP_ID) {
            menu.findItem(R.id.action_delete).setVisible(false);
        }
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.menu_delete, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (this.validate()) {
                    return saveAndReturn() ;
                }
                else return false;
            case R.id.action_delete:
                return deleteAndReturn(id);
            default: return super.onOptionsItemSelected(item);
        }
    }

    private boolean saveAndReturn() {
        String nameTrip = binding.autoCompleteTripName.getText().toString();
        String destinationTrip = binding.autoCompleteDestination.getText().toString();
        String dateTrip = binding.date.getText().toString();
        String riskAssessmentTrip = binding.riskSelected.getText().toString();
        String descriptionTrip = binding.description.getText().toString();

        tripEnity updateTrip
                = new tripEnity(id != null ? id: Constants.NEW_TRIP_ID,nameTrip,destinationTrip, dateTrip,riskAssessmentTrip, descriptionTrip);
        if(id == null){
            tripDao.insert(updateTrip);
        }
        else {
            tripDao.update(updateTrip);
        }
        System.out.println(id);
        Navigation.findNavController(getView()).navigateUp();
        return true;
    }

    private boolean validate() {
        TextInputLayout inputLayoutTripName = binding.name;
        TextInputLayout inputLayoutDestination = binding.destination;

        AutoCompleteTextView textViewTripName = binding.autoCompleteTripName;
        AutoCompleteTextView textViewDestination = binding.autoCompleteDestination;
        EditText description = binding.description;

        boolean isValidated = true;

        if(textViewTripName.getText().toString().isEmpty()) {
            inputLayoutTripName.setError("Trip name is required!");
            isValidated = false;
        }

        if(textViewDestination.getText().toString().isEmpty()) {
            inputLayoutDestination.setError("Destination is required!");
            isValidated = false;
        }
        if (description.getText().toString().equals(Constants.EMPTY_STRING)){
            description.setError("Description is require");
            isValidated = false;
        }
        return isValidated;
    }

    private boolean deleteAndReturn(String id) {
        Log.i(this.getClass().getName(), "delete and return");
        tripDao.delete(id);
        Navigation.findNavController(getView()).navigateUp();
        return true;
    }

    private void showDateTimeDialog(EditText date) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);

                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");

                        date.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(requireContext(), timeSetListener,
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(requireContext(), dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }
    private int checkRadioId(String rId) {
        if(rId == null || rId.equals("true")) {
            rId = "-1";
        }
        return Integer.parseInt(rId);
    }


}
