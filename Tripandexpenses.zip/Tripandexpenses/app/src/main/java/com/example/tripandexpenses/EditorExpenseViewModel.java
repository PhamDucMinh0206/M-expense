package com.example.tripandexpenses;

import androidx.lifecycle.ViewModel;

public class EditorExpenseViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}