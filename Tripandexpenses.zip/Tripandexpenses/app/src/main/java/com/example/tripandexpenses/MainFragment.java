package com.example.tripandexpenses;

import androidx.appcompat.widget.SearchView;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.tripandexpenses.data.SampleDataProvider;
import com.example.tripandexpenses.data.TripDAO;
import com.example.tripandexpenses.data.tripEnity;
import com.example.tripandexpenses.databinding.FragmentMainBinding;

import java.text.ParseException;
import java.util.Optional;

public class MainFragment extends Fragment implements tripListAdapter.ListItemListener {

    private FragmentMainBinding binding;
    private SearchView searchTrip;
    TripDAO tripDao;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentMainBinding.inflate(inflater, container, false);
        try {
            tripDao = new TripDAO(getContext());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        searchTrip = binding.searchTripName;
        searchTrip.clearFocus();
        searchTrip.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                tripDao.search(newText);
                return true;
            }
        });

//        tripEnity t = SampleDataProvider.getTrips().get(0);
//        binding.myText.setText(t.toString());

        RecyclerView rv = binding.RecyclerView;
        rv.setHasFixedSize(true);
        rv.addItemDecoration(new DividerItemDecoration(
                getContext(),
                (new LinearLayoutManager(getContext())).getOrientation())
        );

        tripDao.triplist.observe(
                getViewLifecycleOwner(),
                tripList -> {
                    System.out.println("#trips: " + tripList.size());
                    tripListAdapter adapter = new tripListAdapter(tripList, this);
                    binding.RecyclerView.setAdapter(adapter);
                    binding.RecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                }
        );

        binding.fabAddTrip.setOnClickListener(v -> this.onItemClick(null));


        return binding.getRoot();
//        return inflater.inflate(R.layout.fragment_main, container, false);
    }


    @Override
    public void onItemClick(String tripId) {
        Bundle bundle = new Bundle();
        if (tripId != null) {
            tripEnity trip = tripDao.getById(tripId);
            bundle.putString("id", trip.getId());
            bundle.putString("name", trip.getName());
            bundle.putString("destination", trip.getDestination());
            bundle.putString("date", trip.getDate());
            bundle.putString("risk", trip.getRisk());
            bundle.putString("description", trip.getDescription());
            System.out.println("Trip: "+ bundle);

        }
            Navigation.findNavController(getView()).navigate(R.id.editorFragment, bundle);
    }
    @Override
    public void onResume() {
        super.onResume();
        Log.i(this.getClass().getName(), "onResume");
        tripDao.getAll();
    }
}