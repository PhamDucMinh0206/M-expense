package com.example.tripandexpenses.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBhender extends SQLiteOpenHelper {
    public static final String DB_NAME = "DBtripandexpense";
    public static final String TRIP = "trip";
    public static final String EXPENSE = "expense";
    public  static final int DB_VERSION = 1;

    public DBhender(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String trip = "CREATE TABLE TRIP (" +
                "id integer primary key autoincrement, " +
                "name text not null, " +
                "destination text not null, " +
                "date text not null, " +
                "risk text not null, " +
                "description text not null)";

        String expense = "CREATE TABLE EXPENSE (" +
                "id integer primary key autoincrement, " +
                "idTrip text not null, " +
                "typeOfExpense text not null, " +
                "amount real not null, " +
                "time text not null, " +
                "additionalComments text not null, " +
                "foreign key(idTrip) REFERENCES TRIP (id))";

        db.execSQL(trip);
        db.execSQL(expense);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TRIP);
        db.execSQL("DROP TABLE IF EXISTS "+ EXPENSE);
        onCreate(db);
    }
}
