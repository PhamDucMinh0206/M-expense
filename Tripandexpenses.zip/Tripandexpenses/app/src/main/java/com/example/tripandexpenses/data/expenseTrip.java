package com.example.tripandexpenses.data;

import com.example.tripandexpenses.Constants;

import java.util.HashMap;
import java.util.Map;

public class expenseTrip {
    private String id;
    private String idTrip;
    private String typeOfExpense;
    private double amount;
    private String time;
    private String additionalComments;

    public expenseTrip() {
        this(
                Constants.NEW_EXPENSE_ID,
                Constants.NEW_TRIP_ID,
                Constants.EMPTY_STRING,
                Constants.PRICE_DEFAULT,
                Constants.EMPTY_STRING,
                Constants.EMPTY_STRING
        );
    }

    public expenseTrip(String id, String idTrip, String typeOfExpense, double amountOfTheExpense, String timeOfTheExpense, String additionalComments) {
        this.id = id;
        this.idTrip = idTrip;
        this.typeOfExpense = typeOfExpense;
        this.amount = amountOfTheExpense;
        this.time = timeOfTheExpense;
        this.additionalComments = additionalComments;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdTrip() {
        return idTrip;
    }

    public void setIdTrip(String idTrip) {
        this.idTrip = idTrip;
    }

    public String getTypeOfExpense() {
        return typeOfExpense;
    }

    public void setTypeOfExpense(String typeOfExpense) {
        this.typeOfExpense = typeOfExpense;
    }

    public double getAmountOfTheExpense() {
        return amount;
    }

    public void setAmountOfTheExpense(double amountOfTheExpense) {
        this.amount = amountOfTheExpense;
    }

    public String getTimeOfTheExpense() {
        return time;
    }

    public void setTimeOfTheExpense(String timeOfTheExpense) {
        this.time = timeOfTheExpense;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    @Override
    public String toString() {
        return "Expense{" +
                "id='" + id + '\'' +
                ", idTrip='" + idTrip + '\'' +
                ", typeOfExpense='" + typeOfExpense + '\'' +
                ", amountOfTheExpense='" + amount + '\'' +
                ", timeOfTheExpense='" + time + '\'' +
                ", additionalComments='" + additionalComments +
                '}';
    }

    public Map<String, Object> getMapWithoutId() {
        Map<String, Object> tMap = new HashMap<>();
        tMap.put("idTrip", this.idTrip);
        tMap.put("typeOfExpense", this.typeOfExpense);
        tMap.put("amountOfTheExpense", this.amount);
        tMap.put("timeOfTheExpense", this.time);
        tMap.put("additionalComments", this.additionalComments);
        return tMap;
    }
}
